package android.bignerdranch.criminalintent;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ZoomFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ZoomFragment extends DialogFragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String ARG_PATH = "date";
    private static final String filepath = "filepath";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ZoomFragment() {
        // Required empty public constructor
    }
    public static ZoomFragment newInstance(String fileName) {
            Bundle args = new Bundle();
            args.putString(filepath,fileName);
            ZoomFragment fragment = new ZoomFragment();
            fragment.setArguments(args);
            return fragment;
        }



    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
      //  Log.d("ZOOMFRAG", "after Line 55");
       // Log.d("ZOOMFRAG", fileName);
        String fileName = getArguments().getString(filepath);
       // Log.d("ZOOMFRAG", "after Line 55");
        View v = LayoutInflater.from(getActivity())
                .inflate(R.layout.fragment_zoom, null);
        ImageView imageView = v.findViewById(R.id.zoom_view);
        Bitmap bitmap = BitmapFactory.decodeFile(fileName);
        imageView.setImageBitmap(bitmap);
       //Log.d("ZOOMFRAG", "after Line 55");
        return v;
               // .setView(v)
                //.setTitle(R.string.crime_report_subject)
               // .create();
    }
}